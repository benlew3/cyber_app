# Security+ Platform v34 - New Feature Additions

## 📦 What's Included

This package contains **new files** to add to your existing `cyber_app` repository.

### New JavaScript Files (js/)
| File | Purpose |
|------|---------|
| `interactive-memory-hooks.js` | Self-check system for memory hooks |
| `weak-spots-review.js` | Review page for items marked "review needed" |
| `memory-hooks-integration.js` | Integration layer for lesson viewer |
| `app-memory-hooks-patch.js` | Patches app.js to add memory hooks features |
| `linux-guide.js` | Linux Security Guide viewer (Debian + AlmaLinux) |
| `linux-guide-integration.js` | Adds Linux Guide to navigation & dashboard |

### New CSS Files (css/)
| File | Purpose |
|------|---------|
| `memory-hooks.css` | Styles for memory hooks system |
| `linux-guide.css` | Styles for Linux guide |

### New Data Files (data/)
| File | Purpose |
|------|---------|
| `LINUX-GUIDE-001_Linux_Security_Fundamentals.json` | 118KB Linux guide content |

---

## 🚀 Integration Steps

### Step 1: Copy New Files

Copy the files from this package into your `cyber_app` repository:

```bash
# From this package directory:
cp js/* /path/to/cyber_app/js/
cp css/* /path/to/cyber_app/css/
cp data/* /path/to/cyber_app/data/
```

### Step 2: Update index.html

Add these lines to your `index.html` **in the HEAD section** (after editorial.css):

```html
<!-- NEW: Interactive Memory Hooks Styles -->
<link rel="stylesheet" href="css/memory-hooks.css">

<!-- NEW: Linux Security Guide Styles -->
<link rel="stylesheet" href="css/linux-guide.css">
```

Add these lines to your `index.html` **in the SCRIPT section** (after enhanced-lesson-viewer.js):

```html
<!-- INTERACTIVE MEMORY HOOKS SYSTEM -->
<script src="js/interactive-memory-hooks.js"></script>
<script src="js/weak-spots-review.js"></script>
<script src="js/memory-hooks-integration.js"></script>
<script src="js/app-memory-hooks-patch.js"></script>

<!-- LINUX SECURITY GUIDE -->
<script src="js/linux-guide.js"></script>
<script src="js/linux-guide-integration.js"></script>
```

**Or** simply replace your existing `index.html` with the included `index.html` file.

### Step 3: Verify Load Order

The script load order is critical. Ensure:
1. `utils.js` loads first
2. `app.js` loads before patch files
3. Patch files load after their dependencies

---

## ✨ New Features

### 🧠 Interactive Memory Hooks
- **Self-check cards** in each lesson section
- Click to reveal explanation
- Mark as "I knew this" or "Review needed"
- Progress tracking with visual progress bars
- **Weak Spots Review** page for focused study
- Badge shows count of items needing review

### 🐧 Linux Security Guide
- Dual-distro support (Debian + AlmaLinux)
- Toggle to view one distro or both
- VM setup guides for both distributions
- Command reference organized by category
- Quick reference card
- Keyboard shortcut: **Ctrl+Shift+L**

---

## 🔧 How It Works

### Memory Hooks Flow
1. User studies lesson with memory hooks
2. Clicks mistake card to reveal explanation
3. Self-checks: "Yes I knew" or "No, review needed"
4. Items marked for review appear in Weak Spots page
5. Navigation badge shows count of weak spots
6. User reviews weak spots until mastered

### Linux Guide Flow
1. User clicks "🐧 Linux Guide" in navigation
2. Selects distribution preference (Debian/AlmaLinux/Both)
3. Browses chapters and command references
4. Uses Quick Reference for common commands

---

## 📊 Storage Keys

The features use localStorage with these keys:
- `secplus_weak_spots` - Set of mistake IDs marked for review
- `secplus_mastered` - Set of mistake IDs marked as mastered
- `linux_distro_preference` - User's distro preference

---

## 🎨 Design System

Uses existing design tokens:
- Backgrounds: `#09090b`, `#18181b`, `#27272a`
- Text: `#fafafa`, `#a1a1aa`, `#71717a`
- Success: `#10b981` | Error: `#ef4444`
- Memory Hook accents: Pink (mnemonic), Blue (analogy)

---

## 📝 Version Info

- **Version:** v34
- **Date:** January 13, 2026
- **Previous:** v33 (41 enriched lessons)

---

## 🐛 Troubleshooting

### Memory hooks not showing?
1. Check that `memory-hooks.css` is loaded
2. Verify script load order in index.html
3. Check browser console for errors

### Linux Guide not appearing?
1. Verify `linux-guide.js` and `linux-guide-integration.js` are loaded
2. Check that `LINUX-GUIDE-001_*.json` is in `/data/`
3. Try keyboard shortcut: Ctrl+Shift+L

### Scripts not loading?
1. Ensure `utils.js` loads before all other scripts
2. Check that all file paths are correct
3. Verify no 404 errors in Network tab

---

## 📁 Full File List

```
security-plus-additions/
├── js/
│   ├── interactive-memory-hooks.js    (23KB)
│   ├── weak-spots-review.js           (14KB)
│   ├── memory-hooks-integration.js    (8KB)
│   ├── app-memory-hooks-patch.js      (14KB)
│   ├── linux-guide.js                 (47KB)
│   └── linux-guide-integration.js     (15KB)
├── css/
│   ├── memory-hooks.css               (17KB)
│   └── linux-guide.css                (40KB)
├── data/
│   └── LINUX-GUIDE-001_*.json         (118KB)
├── index.html                         (Updated)
├── QUICK_CONTEXT.md                   (Updated)
└── README.md                          (This file)
```

---

*Happy studying! 🎓*
